# FortEvo — Brand Kit

Referência completa pra quem for usar a marca fora do app (site, materiais impressos, stores, etc.).
Pra entender o *porquê* de cada decisão, comece pelo manual.

## Onde está cada coisa

- **manual/** — o manual de marca completo (personalidade, logotipo, cor, tipografia, voz, aplicação).
  Abra `manual-de-marca.html` no navegador, ou use o `manual-de-marca.pdf` pra imprimir/compartilhar.
- **marca-vetor/** — fonte vetorial (SVG), pra qualquer tamanho novo. Nunca redesenhe a mão a partir do raster.
  - `fortevo-mark.svg` — a marca isolada (monograma F+E).
  - `fortevo-app-icon.svg` — composição aprovada do ícone de app (fundo tinta + marca papel, cantos já no raio certo).
- **marca-raster/** — exports prontos pra uso fora do app.
  - `favicon.ico` — multi-resolução (16/32/48px).
  - `fortevo-mark-tinta-1024.png` — marca escura sobre transparente, 1024px.
  - `fortevo-mark-papel-512.png` — marca clara sobre transparente, 512px.
- **app-icons/** — os mesmos arquivos que já estão integrados em `app/assets/` no repo (ícone iOS, ícone adaptativo Android, favicon, splash). Aqui só como cópia de referência.

## Essencial, se for usar a marca em algo novo

- Tinta `#15140F` · Papel `#F5F3EE` · Azul Protocolo (acento) `#3A64FF`.
- Marca sempre monocromática — nunca recolorida com o acento, sem gradiente/sombra/contorno, sem distorcer.
- Banido: halteres, barras, chamas, raios, escudos, silhuetas musculosas, e o vermelho/laranja genérico de "Sports Fitness".
- Tabela completa de tokens de cor, estados e regras de contraste: ver o manual.

out/2026
